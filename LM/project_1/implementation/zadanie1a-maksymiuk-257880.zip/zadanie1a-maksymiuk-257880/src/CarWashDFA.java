import java.util.ArrayList;
import java.util.List;

/**
 * Program symulujący automat do pobierania opłat w myjni samochodowej
 * wykorzystujący model deterministycznego automatu skończonego (DFA).
 *
 * @author Maciej Maksymiuk
 */
public class CarWashDFA {
    private static final int INITIAL_STATE = 0;
    private static final int END_STATE = 15;
    private static final int INVALID_STATE = -1;
    
    // Tablica przechowująca resztę dla każdego stanu
    private static final int[] CHANGE_TABLE = new int[20];
    
    // Tablica przechowująca sumę wrzuconych monet dla każdego stanu
    private static final int[] TOTAL_AMOUNT_TABLE = new int[20];
    
    private static final int[][] TRANSITION_TABLE = new int[20][4];
    private final List<Integer> stateHistory = new ArrayList<>();
    private final List<Integer> coinHistory = new ArrayList<>();
    private int currentState = INITIAL_STATE;
    private boolean isErrorState = false;
    
    public CarWashDFA() {
        initializeTransitionTable();
        initializeChangeTable();
        initializeTotalAmountTable();
        stateHistory.add(0);
    }
    
    // Inicjalizacja tablicy reszty dla każdego stanu
    private void initializeChangeTable() {
        CHANGE_TABLE[15] = 0;  // Stan końcowy - dokładnie 15zł
        CHANGE_TABLE[16] = 1;  // Stan końcowy - nadpłata 1zł
        CHANGE_TABLE[17] = 2;  // Stan końcowy - nadpłata 2zł
        CHANGE_TABLE[18] = 3;  // Stan końcowy - nadpłata 3zł
        CHANGE_TABLE[19] = 4;  // Stan końcowy - nadpłata 4zł
    }
    
    // Inicjalizacja tablicy sum dla każdego stanu
    private void initializeTotalAmountTable() {
        for (int i = 0; i < 20; i++) {
            TOTAL_AMOUNT_TABLE[i] = i;  // Każdy stan odpowiada sumie monet
        }
    }
    
    private void initializeTransitionTable() {
        TRANSITION_TABLE[0] = new int[]{0, 1, 2, 5};
        TRANSITION_TABLE[1] = new int[]{1, 2, 3, 6};
        TRANSITION_TABLE[2] = new int[]{2, 3, 4, 7};
        TRANSITION_TABLE[3] = new int[]{3, 4, 5, 8};
        TRANSITION_TABLE[4] = new int[]{4, 5, 6, 9};
        TRANSITION_TABLE[5] = new int[]{5, 6, 7, 10};
        TRANSITION_TABLE[6] = new int[]{6, 7, 8, 11};
        TRANSITION_TABLE[7] = new int[]{7, 8, 9, 12};
        TRANSITION_TABLE[8] = new int[]{8, 9, 10, 13};
        TRANSITION_TABLE[9] = new int[]{9, 10, 11, 14};
        TRANSITION_TABLE[10] = new int[]{10, 11, 12, 15};
        TRANSITION_TABLE[11] = new int[]{11, 12, 13, 16};
        TRANSITION_TABLE[12] = new int[]{12, 13, 14, 17};
        TRANSITION_TABLE[13] = new int[]{13, 14, 15, 18};
        TRANSITION_TABLE[14] = new int[]{14, 15, 16, 19};
        
        for (int i = 15; i < 20; i++) {
            TRANSITION_TABLE[i] = new int[]{i, INVALID_STATE, INVALID_STATE, INVALID_STATE};
        }
    }
    
    public void displayTransitionTable() {
        System.out.println("TABLICA PRZEJŚĆ");
        int columnWidth = 8;
        
        String header = String.format("%-" + columnWidth + "s", "δ");
        header += String.format("%-" + columnWidth + "s", "1");
        header += String.format("%-" + columnWidth + "s", "2");
        header += String.format("%-" + columnWidth + "s", "5");
        
        String horizontalLine = "-".repeat(columnWidth * 4);
        
        System.out.println(header);
        System.out.println(horizontalLine);
        
        for (int i = 0; i < TRANSITION_TABLE.length; i++) {
            String row = String.format("%-" + columnWidth + "s", "q" + i);
            
            if (i < 15) {
                for (int j = 1; j < 4; j++) {
                    row += String.format("%-" + columnWidth + "s", "q" + TRANSITION_TABLE[i][j]);
                }
            } else {
                for (int j = 1; j < 4; j++) {
                    row += String.format("%-" + columnWidth + "s", "--");
                }
            }
            System.out.println(row);
        }
    }
    
    public void insertCoin(int coin) {
        if (isErrorState) {
            System.out.println("Automat w stanie błędu. Nie można wrzucać kolejnych monet.");
            return;
        }
        
        coinHistory.add(coin);
        
        int coinIndex = getCoinIndex(coin);
        int nextState = TRANSITION_TABLE[currentState][coinIndex];
        
        if (nextState == INVALID_STATE) {
            isErrorState = true;
            System.out.println("BŁĄD: Nieprawidłowa sekwencja monet!");
            printTicket();
            return;
        }
        
        currentState = nextState;
        stateHistory.add(currentState);
        
        System.out.println("Wrzucono: " + coin + " zł.");
        System.out.println("Kredyt: " + TOTAL_AMOUNT_TABLE[currentState] + " zł.");
        System.out.println("Aktualny stan automatu: q" + currentState);
        
        if (currentState >= 15) {
            printTicket();
        }
    }
    
    private void printTicket() {
        System.out.println("\n=== BILET NA MYCIE ===");
        System.out.println("Wartość: 15 zł");
        
        if (currentState >= 15) {
            int change = CHANGE_TABLE[currentState];
            if (change > 0) {
                System.out.println("Reszta do wydania: " + change + " zł");
            }
        }
        
        System.out.println("==================\n");
        
        System.out.println("Historia wpłat: ");
        for (Integer coin : coinHistory) {
            System.out.print("---" + coin);
        }
        System.out.println();
        
        System.out.println("Historia stanów automatu:");
        for (Integer state : stateHistory) {
            System.out.print("---q" + state);
        }
        
        System.out.println("\nStan końcowy: q" + currentState);
    }
    
    private int getCoinIndex(int coin) {
        return switch (coin) {
            case 1 -> 1;
            case 2 -> 2;
            case 5 -> 3;
            default -> throw new IllegalStateException("Nieprawidłowy nominał monety: " + coin);
        };
    }
    
    public int getCurrentState() {
        return currentState;
    }
    
    public boolean isInErrorState() {
        return isErrorState;
    }
}
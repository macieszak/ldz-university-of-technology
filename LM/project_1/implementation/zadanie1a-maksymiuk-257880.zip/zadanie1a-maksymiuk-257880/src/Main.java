import java.util.Scanner;

/**
 * Klasa główna programu symulującego automat do pobierania opłat w myjni samochodowej.
 *
 * @author Maciej Maksymiuk
 */
public class Main {
    public static void main(String[] args) {
        CarWashDFA carWashDFA = new CarWashDFA();
        carWashDFA.displayTransitionTable();
        
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("MYJNIA SAMOCHODWA");
        System.out.println("Cena mycia: 15 zł");
        System.out.println("Akceptowane monety: 1 zł, 2 zł, 5 zł");
        
        while (carWashDFA.getCurrentState() < 15 && !carWashDFA.isInErrorState()) {
            System.out.println("\nWrzuć monetę (1, 2 lub 5 zł):");
            String input = scanner.nextLine().trim();
            
            if (!input.matches("^\\d+$")) {
                System.out.println("Błąd: Wprowadź pojedynczą liczbę!");
                return;
            }
            
            int coin = Integer.parseInt(input);
            
            if (coin != 1 && coin != 2 && coin != 5) {
                System.out.println("Błąd: Nieakceptowany nominał monety!");
                return;
            }
            
            carWashDFA.insertCoin(coin);
        }
    }
}